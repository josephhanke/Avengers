﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Star_Wars
{
    public partial class _default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            // 1.  Reverse your name
            string name = "Joseph Hanke";
            // In my case, the result would be:
            // eknaH hpesoJ



            // 2.  Reverse this sequence:
            string names = "Porg,Leia,Poe,Chewbacca";
           
                        
            // When you're finished it should look like this:
            // Chewbacca,Poe,Leia,Porg




            // 3. Use the sequence to create ascii art:
            // *****Porg*****
            // *****Leia*****
            // *****Poe******
            // **Chewbacca***





            // 4. Solve this puzzle:

            string puzzle = "I ONLY KNOW ONE BRUBH,remove-me IBS BIME FOR BHE JEDI BO END";

            //Once you fix it with string methods, it should read:
            //I only know one truth, its time for the Jedi to end.

         

        


            /* 5. EXTENSION. 
             Fix the following by using string methods */

           string squidLake = "ZIZ YOU EVER HEAR THE TRAGEZY OF ZARTH PLAGUEIS THE WISE? I THOUGHT NOT. IT’S NOT A STORY THE JEZI WOULZ TELL YOU. " +
                "IT’S A SITH LEGENZ. ZARTH PLAGUEIS WAS A ZARK LORZ OF THE SITH, SO darksideoftheforcePOWERFUL ANZ SO WISE HE COULZ USE THE FORCE TO INFLUENCE THE MIZICHLORIANS TO CREATE LIFE… " +
                "HE HAZ SUCH A KNOWLEZGE OF THE ZARK SIZE THAT HE COULZ EVEN KEEP THE ONES HE CAREZ ABOUT FROM ZYING. " +
                "THE ZARK SIZE OF THE FORCE IS A PATHWAY TO MANY ABILITIES SOME CONSIZER TO BE UNNATURAL. " +
                "HE BECAME SO POWERFUL… THE ONLY THING HE WAS AFRAIZ OF WAS LOSING HIS POWER, WHICH EVENTUALLY, OF COURSE, HE ZIZ. " +
                "UNFORTUNATELY, HE TAUGHT HIS APPRENTICE EVERYTHING HE KNEW, THEN HIS APPRENTICE KILLEZ HIM IN HIS SLEEP. " +
                "IRONIC. HE COULZ SAVE OTHERS FROM ZEATH, BUT NOT HIMSELF";

        }
    }
}