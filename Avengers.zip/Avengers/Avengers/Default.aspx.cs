﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Avengers
{
    public partial class Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {



            string[] names = new string[] { "Iron Man", "Thor", "Hulk", "Black Widow", "Captain America", "Hawkeye", "Ant-Man", "Scarlet Witch", "Black Panther", "Vision" };

            int[] numbers = new int[] { 7, 9, 12, 15, 17, 13, 2, 6, 8, 13 };
                              

            string result = "";
                      
            resultLabel.Text = result.ToString();

        }
    }
}